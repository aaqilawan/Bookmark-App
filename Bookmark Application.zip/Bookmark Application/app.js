document.getElementById('myform').addEventListener('submit', bookmark);

function bookmark(e) {
    e.preventDefault();
    let siteName = document.getElementById('siteName').value;
    let siteUrl = document.getElementById('siteUrl').value;

    //not empty input field
    if (!siteName && !siteUrl) {
        alert("please fill the field");
        return false;
    }
    //regular expression
    var expression = /[-a-zA-Z0-9@:%._\+~#=]{1,256}\.[a-zA-Z0-9()]{1,6}\b([-a-zA-Z0-9()@:%_\+.~#?&//=]*)?/gi;
    var regex = new RegExp(expression);
    if (!siteUrl.match(regex)) {
        alert("please fill url");
        return false;
    }

    //store in the object sitename and siteurl
    let bookmark = {
        name: siteName,
        url: siteUrl
    }

    //if localstoage empty then fill the data
    var bookmarks = [];
    if (localStorage.getItem('bookmarks') === null) {
        bookmarks.push(bookmark);
        localStorage.setItem('bookmarks', JSON.stringify(bookmarks));
    }
    //if already data then add more data in it
    else {
        var bookmarks = JSON.parse(localStorage.getItem('bookmarks'));
        bookmarks.push(bookmark);
        localStorage.setItem('bookmarks', JSON.stringify(bookmarks));
    }
    
    //reser the form enter whos
    document.getElementById('myform').reset();

    abc();
}


//delete the url
function deleteBookmark(url) {
    var bookmarks = JSON.parse(localStorage.getItem('bookmarks'));
    for (var i = 0; i < bookmarks.length; i++) {
        if (bookmarks[i].url == url) {
            bookmarks.splice(i, 1);
        }
    }
    localStorage.setItem('bookmarks', JSON.stringify(bookmarks));
    abc();
}


//add the page functionality
function abc() {
    var bookmarks = JSON.parse(localStorage.getItem('bookmarks'));
    var result = document.getElementById('siteResult');

    result.innerHTML = '';
    for (var i = 0; i < bookmarks.length; i++) {
        var name = bookmarks[i].name;
        var url = bookmarks[i].url;
        result.innerHTML += '<div class="well">' +
            name + '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;' +
            '<a class="btn btn-secondary" target="_blank" href="' + url + '"> Visit </a>' + '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;' +
            '<a onclick="deleteBookmark(\'' + url + '\')" class="btn btn-danger" href="#">Delete</a>' +
            '</div>'
    }
}